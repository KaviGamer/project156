import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import { createStackNavigator } from 'react-navigation-stack';
import { createAppContainer } from 'react-navigation';

import DeTaIlScReEn from './screens/details.js';
import HoMeScReEn from './screens/home.js';

export default class App extends React.Component {
  render() {
    return(<AppCont/>)
  }
}

const irdk = createStackNavigator(
  {
    HoMeScReEn: {
      screen: HoMeScReEn,
      navigationOptions: {
        headerShown: false,
      },
    },
    DeTaIlScReEn: {
      screen: DeTaIlScReEn,
      navigationOptions: {
        headerShown: false,
      },
    },
  },
  {
    initialRouteName: 'HoMeScReEn',
  }
);
const AppCont = createAppContainer(irdk);