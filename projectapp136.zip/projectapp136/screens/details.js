import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';

export default class DeTaIlScReEn extends React.Component{
  render(){
  return(
    <View>
    <Text>DeTaIlScReEn</Text>
    </View>
  )}
}