import * as React from 'react';
import {
  Text,
  View,
  StyleSheet,
  FlatList,
  Alert,
  SafeAreaView,
} from 'react-native';
import { ListItem } from 'react-native-elements';
import axios from 'axios';

export default class HoMeScReEn extends React.Component {
  constructor() {
    super();
    this.state = {
      listdata: [],
      url: 'http://localhost:5000/',
    };
  }
  render() {
    return (
      <View>
        <Text>HoMeScReEn</Text>
      </View>
    );
  }
  componentDidMount() {
    this.getPlanets();
  }
  getPlanets = () => {
    const { url } = this.state.url;
    axios.get(url).then((response) => {
      return this.setState({
        listdata: response.data.data,
      });
    }).catch(error=>{
      Alert.alert("404 ERROR PLS CHECK YOUR LAPTOP ITS VERY SMALL AND OUTDATED AND AHAHAHHAHAHAHAHAHA")
    })
  };
}
